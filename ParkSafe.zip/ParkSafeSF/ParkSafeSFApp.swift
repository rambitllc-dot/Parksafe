import SwiftUI
import UserNotifications

@main
struct ParkSafeSFApp: App {
    @StateObject private var scheduleStore       = ScheduleStore()
    @StateObject private var locationManager     = LocationManager()
    @StateObject private var notificationManager = NotificationManager()
    @AppStorage("hasCompletedOnboarding") private var hasCompletedOnboarding = false

    var body: some Scene {
        WindowGroup {
            Group {
                if hasCompletedOnboarding {
                    ContentView()
                } else {
                    OnboardingView(hasCompletedOnboarding: $hasCompletedOnboarding)
                }
            }
            .environmentObject(scheduleStore)
            .environmentObject(locationManager)
            .environmentObject(notificationManager)
        }
    }
}
