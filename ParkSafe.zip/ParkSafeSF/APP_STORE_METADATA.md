# ParkSafe SF — App Store Connect Metadata
# Copy-paste ready for App Store Connect submission

## APP INFORMATION

App Name:           ParkSafe SF
Subtitle:           Street Cleaning Alerts
Bundle ID:          com.parksafesf.app  (change to yours)
SKU:                PARKSAFESF-001
Primary Language:   English (U.S.)
Category:           Navigation
Secondary Category: Utilities
Content Rights:     Does not contain third-party content
Age Rating:         4+ (no objectionable content)


## VERSION 1.0 METADATA

### Description (max 4000 chars)
---
Never get a San Francisco parking ticket again.

ParkSafe SF tracks street cleaning schedules across 25+ San Francisco streets and sends you smart alerts before your car gets ticketed — so you can move it on time, every time.

HOW IT WORKS
Open the app and you'll see a live map of SF streets color-coded by status: green means safe to park, amber means you need to move soon, and red means move now. Tap any pin to see the exact cleaning window and navigate there instantly with Apple Maps or Google Maps.

SMART NOTIFICATIONS
• Night before reminder — get alerted at 9 PM when cleaning is tomorrow
• 30-minute warning — your last chance to move before it starts
• Cleaning started alert — urgent push if you're still parked
• Safe day confirmation — optional alert when your street is clear

WEEKLY SCHEDULE
See the full week at a glance for all your saved streets. Know exactly which days require you to move and plan ahead.

COVERAGE
Mission District, Castro, Noe Valley, Haight-Ashbury, NoPa, Lower Pacific Heights, Cow Hollow, Marina District, North Beach, Chinatown, Polk Gulch, SoMa, Potrero Hill, Inner Richmond, Inner Sunset, and more neighborhoods across San Francisco.

FEATURES
• Interactive MapKit map with real-time colored status pins
• Search all 25 streets by name or neighborhood
• Bookmark your streets for quick access
• One-tap navigation to Apple Maps or Google Maps
• Full dark mode support
• No account required — all data stays on your device
• Data sourced from SF Open Data (data.sfgov.org)

DISCLAIMER
Street cleaning schedules are sourced from SF Open Data and may not reflect temporary changes, street fairs, or holidays. Always verify with posted signs.
---

### What's New (Version 1.0)
---
Initial release of ParkSafe SF.
---

### Keywords (max 100 chars, comma-separated)
---
parking,SF,San Francisco,street cleaning,street sweeping,ticket,SFMTA,alert,notification
---

### Support URL
https://parksafesf.app/support

### Marketing URL (optional)
https://parksafesf.app

### Privacy Policy URL (REQUIRED — must be live URL)
https://parksafesf.app/privacy


## PRICING

Price Tier:         Free (Tier 0)
Availability:       All territories
In-App Purchases:   None


## APP REVIEW INFORMATION

### Notes for Reviewer
---
ParkSafe SF is a parking alert app for San Francisco residents. It uses location services to show nearby street cleaning schedules on a map.

To test the app:
1. Launch the app and complete onboarding (3 slides, tap "Get Started")
2. Allow location permission when prompted (optional — app works without it)
3. Allow notification permission when prompted
4. On the Map tab, tap any colored pin to see a street's cleaning schedule
5. Tap the bookmark icon to save a street
6. Visit the Schedule tab to see saved streets' weekly schedule
7. Visit Settings to configure notification preferences

No login or account is required. All data is stored locally.

The app does not contain any objectionable content. Parking schedule data is sourced from the public SF Open Data portal.
---

### Demo Account
Not required — no login functionality.

### Contact Information (must be filled in App Store Connect)
First Name:    [Your First Name]
Last Name:     [Your Last Name]
Phone:         [Your Phone]
Email:         [Your Email]


## SCREENSHOT REQUIREMENTS

### Required Sizes
1. iPhone 6.7" — 1290 × 2796 px  (iPhone 15 Pro Max)
2. iPhone 6.5" — 1284 × 2778 px  (iPhone 14 Plus)

### Optional
3. iPad Pro 12.9" — 2048 × 2732 px

### Recommended 5 Screenshots (in order)
1. Map tab — zoomed into Mission District, pins visible, bottom sheet showing "Safe to park"
   Caption: "Live map of SF street cleaning zones"

2. Map tab — bottom sheet showing amber warning "Move by 9 AM tomorrow"
   Caption: "Know exactly when to move your car"

3. Onboarding slide 2 — notification illustration
   Caption: "Smart alerts — night before, 30 min warning, and more"

4. Schedule tab — weekly calendar with saved streets
   Caption: "See your full week at a glance"

5. Settings tab — notification toggles
   Caption: "Customize your alerts"

### Tools to capture screenshots
- Xcode Simulator: Device → iPhone 15 Pro Max → File → Save Screenshot
- Or use fastlane snapshot for automated screenshots


## BUILD & ARCHIVE COMMANDS

# 1. Set your Team ID in project.pbxproj and ExportOptions.plist first

# 2. Clean build folder
xcodebuild clean -project ParkSafeSF.xcodeproj -scheme ParkSafeSF

# 3. Archive
xcodebuild archive \
  -project ParkSafeSF.xcodeproj \
  -scheme ParkSafeSF \
  -configuration Release \
  -archivePath ./build/ParkSafeSF.xcarchive \
  -allowProvisioningUpdates

# 4. Export to App Store
xcodebuild -exportArchive \
  -archivePath ./build/ParkSafeSF.xcarchive \
  -exportPath ./build/AppStore \
  -exportOptionsPlist ExportOptions.plist \
  -allowProvisioningUpdates

# 5. Upload via altool (or just use Transporter app)
xcrun altool --upload-app \
  -f ./build/AppStore/ParkSafeSF.ipa \
  -t ios \
  -u "your@apple.id" \
  -p "@keychain:AC_PASSWORD"


## CHECKLIST BEFORE SUBMITTING

### Code
[ ] Replace YOUR_TEAM_ID in project.pbxproj
[ ] Replace YOUR_TEAM_ID in ExportOptions.plist
[ ] Replace com.parksafesf.app with your bundle ID everywhere
[ ] Update privacy policy URL in SettingsView.swift
[ ] Update terms URL in SettingsView.swift

### Assets
[ ] Add 1024×1024 AppIcon.png to Assets.xcassets/AppIcon.appiconset/
[ ] Verify app runs on iPhone 15 Pro Max simulator without crashes
[ ] Verify dark mode looks correct (Settings → Developer → Dark Appearance)

### App Store Connect
[ ] App record created with matching bundle ID
[ ] Privacy policy URL is live and accessible
[ ] All 5 screenshots uploaded (1290×2796 and 1284×2778)
[ ] Description, keywords, subtitle filled in
[ ] Age rating questionnaire completed (result: 4+)
[ ] Support URL filled in (can be a GitHub page or simple landing page)
[ ] Review notes filled in

### Legal
[ ] Copyright year correct in App Store Connect (© 2025 Your Name)
[ ] You own or have rights to all app content
[ ] SF Open Data attribution in Settings (already included)
