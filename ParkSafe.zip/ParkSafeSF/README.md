# ParkSafe SF — iOS App

> Never get a San Francisco parking ticket again.

## Project Structure

```
ParkSafeSF/
├── ParkSafeSF.xcodeproj/          ← Open this in Xcode
├── ExportOptions.plist            ← Archive export config
├── APP_STORE_METADATA.md          ← Copy-paste App Store submission text
└── ParkSafeSF/
    ├── ParkSafeSFApp.swift        ← @main entry + onboarding gate
    ├── Info.plist                 ← All permissions + URL schemes
    ├── LaunchScreen.storyboard    ← Launch screen
    ├── Assets.xcassets/           ← AppIcon + 8 semantic color sets (light+dark)
    ├── Models/Models.swift        ← StreetSegment, ParkingStatus, AlertItem
    ├── Services/
    │   ├── ScheduleStore.swift        ← 25 streets + UserDefaults
    │   ├── LocationManager.swift      ← CoreLocation
    │   ├── NotificationManager.swift  ← Push notification scheduling
    │   ├── SFOpenDataService.swift    ← Live API + offline cache
    │   └── ParkingDetectionEngine.swift ← Background auto-detect
    └── Views/
        ├── ContentView.swift          ← TabView root
        ├── OnboardingView.swift       ← 3-screen onboarding
        ├── HomeMapView.swift          ← Map + pins + bottom sheet
        ├── StreetFullDetailView.swift
        ├── SearchView.swift
        ├── AlertsView.swift
        ├── ScheduleView.swift
        └── SettingsView.swift
```

---

## Quick Start (5 minutes to run on your iPhone)

1. Open `ParkSafeSF.xcodeproj` in Xcode 15+
2. Plug in your iPhone
3. Select your device from the scheme picker
4. **Targets → ParkSafeSF → Signing & Capabilities → Team**: pick your Apple ID
5. Press **⌘R**

---

## App Store Submission — What to Change

| File | Change |
|------|--------|
| `project.pbxproj` | Replace `YOUR_TEAM_ID` and `com.parksafesf.app` |
| `ExportOptions.plist` | Replace `YOUR_TEAM_ID` |
| `Assets.xcassets/AppIcon.appiconset/` | Add 1024×1024 PNG app icon |
| `SettingsView.swift` | Update privacy policy + terms URLs |

Then: **Product → Archive → Distribute App → App Store Connect**

See `APP_STORE_METADATA.md` for the full submission checklist and copy-paste descriptions.

---

## Features

- Live MapKit map, 25 SF streets, color-coded status pins
- Street bottom sheet: status banner, week strip, Maps buttons
- Smart push notifications: night-before, 30-min warning, cleaning now
- Background parking auto-detection
- SF Open Data live API with 1-week offline cache
- Weekly schedule for saved streets
- Search by street name or neighborhood
- Full dark mode, onboarding, privacy policy, terms

## Tech Stack

Swift 5.9 · SwiftUI · MapKit · CoreLocation · UserNotifications · URLSession · No third-party dependencies · iOS 17+
