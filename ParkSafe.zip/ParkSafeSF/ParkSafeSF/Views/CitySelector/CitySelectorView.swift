import SwiftUI
import CoreLocation

struct CitySelectorView: View {
    @EnvironmentObject var cityStore: CityStore
    @EnvironmentObject var locationManager: LocationManager
    @Environment(\.dismiss) private var dismiss
    @State private var notifiedCities: Set<String> = []

    var body: some View {
        NavigationStack {
            List {
                // Auto-detect
                Section {
                    Button(action: autoDetect) {
                        HStack(spacing: 14) {
                            Image(systemName: "location.fill")
                                .foregroundColor(.white)
                                .frame(width: 32, height: 32)
                                .background(Color("BrandGreen"))
                                .clipShape(RoundedRectangle(cornerRadius: 8))

                            Text(String(localized: "citySelector.autoDetect"))
                                .foregroundColor(.primary)
                                .font(.system(size: 16, weight: .medium))
                        }
                    }
                }

                // Available cities
                Section(String(localized: "citySelector.available")) {
                    ForEach(CityRegistry.available) { city in
                        CityRow(city: city,
                                isActive: city.id == cityStore.activeCity.id,
                                onSelect: {
                                    cityStore.activeCity = city
                                    dismiss()
                                })
                    }
                }

                // Coming soon
                Section(String(localized: "citySelector.comingSoon")) {
                    ForEach(CityRegistry.comingSoon) { city in
                        ComingSoonRow(city: city,
                                      isNotified: notifiedCities.contains(city.id),
                                      onNotify: { toggleNotify(city) })
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle(String(localized: "citySelector.title"))
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                            .font(.title3)
                    }
                }
            }
        }
        .onAppear {
            let saved = UserDefaults.standard.stringArray(forKey: "notifiedCities") ?? []
            notifiedCities = Set(saved)
        }
    }

    private func autoDetect() {
        locationManager.requestPermission()
        if let loc = locationManager.userLocation {
            if let city = CityRegistry.nearest(to: loc) {
                cityStore.activeCity = city
                dismiss()
            }
        }
    }

    private func toggleNotify(_ city: City) {
        if notifiedCities.contains(city.id) {
            notifiedCities.remove(city.id)
        } else {
            notifiedCities.insert(city.id)
        }
        UserDefaults.standard.set(Array(notifiedCities), forKey: "notifiedCities")
    }
}

// MARK: - City Row (available)

struct CityRow: View {
    let city: City
    let isActive: Bool
    let onSelect: () -> Void

    var body: some View {
        Button(action: onSelect) {
            HStack(spacing: 14) {
                Text(city.flagEmoji)
                    .font(.system(size: 28))
                    .frame(width: 44, height: 44)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 10))

                VStack(alignment: .leading, spacing: 2) {
                    Text(city.localizedName)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.primary)
                    Text(city.country)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }

                Spacer()

                if isActive {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(Color("BrandGreen"))
                        .font(.title3)
                }
            }
        }
        .buttonStyle(.plain)
        .padding(.vertical, 2)
    }
}

// MARK: - Coming Soon Row

struct ComingSoonRow: View {
    let city: City
    let isNotified: Bool
    let onNotify: () -> Void

    var body: some View {
        HStack(spacing: 14) {
            Text(city.flagEmoji)
                .font(.system(size: 28))
                .frame(width: 44, height: 44)
                .background(Color(.tertiarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .opacity(0.6)

            VStack(alignment: .leading, spacing: 2) {
                Text(city.localizedName)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.secondary)
                Text(String(localized: "citySelector.comingSoon"))
                    .font(.caption)
                    .foregroundColor(.tertiary)
            }

            Spacer()

            Button(action: onNotify) {
                if isNotified {
                    Label(String(localized: "citySelector.notified"), systemImage: "bell.fill")
                        .font(.caption.bold())
                        .foregroundColor(Color("BrandGreen"))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color("StatusGreenBG"))
                        .clipShape(Capsule())
                } else {
                    Label(String(localized: "citySelector.notifyMe"), systemImage: "bell")
                        .font(.caption.bold())
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(Capsule())
                }
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 2)
    }
}

#Preview {
    CitySelectorView()
        .environmentObject(CityStore())
        .environmentObject(LocationManager())
}
