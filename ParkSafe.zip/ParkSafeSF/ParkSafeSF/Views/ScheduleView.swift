import SwiftUI

struct ScheduleView: View {
    @EnvironmentObject var store: ScheduleStore

    private let weekdays = Calendar.current.weekdaySymbols
    private var todayWeekday: Int { Calendar.current.component(.weekday, from: .now) }

    var body: some View {
        NavigationStack {
            if store.savedStreets.isEmpty {
                ContentUnavailableView(
                    "No Saved Streets",
                    systemImage: "bookmark.slash",
                    description: Text("Tap the bookmark icon on any street to add it to your schedule.")
                )
                .navigationTitle("Schedule")
            } else {
                List {
                    ForEach(1...7, id: \.self) { wd in
                        let entries = store.savedStreets.flatMap { s in
                            s.cleaningDays.filter { $0.weekday == wd }.map { (s, $0) }
                        }
                        Section {
                            if entries.isEmpty {
                                HStack {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(Color("StatusGreen"))
                                    Text("No cleaning on your saved streets")
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                                .padding(.vertical, 6)
                            } else {
                                ForEach(entries, id: \.0.id) { (street, schedule) in
                                    ScheduleRow(street: street, schedule: schedule)
                                        .listRowInsets(EdgeInsets(top: 4, leading: 16, bottom: 4, trailing: 16))
                                }
                            }
                        } header: {
                            HStack(spacing: 8) {
                                Text(weekdays[wd - 1])
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(.primary)
                                if wd == todayWeekday {
                                    Text("TODAY")
                                        .font(.system(size: 10, weight: .bold))
                                        .foregroundColor(Color("BrandGreen"))
                                        .padding(.horizontal, 7).padding(.vertical, 3)
                                        .background(Color("BrandGreen").opacity(0.12))
                                        .clipShape(Capsule())
                                }
                                Spacer()
                                if entries.isEmpty {
                                    Text("Clear ✓")
                                        .font(.system(size: 13, weight: .medium))
                                        .foregroundColor(Color("StatusGreen"))
                                }
                            }
                            .textCase(nil)
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .navigationTitle("Schedule")
                .navigationBarTitleDisplayMode(.large)
            }
        }
    }
}

struct ScheduleRow: View {
    let street: StreetSegment
    let schedule: CleaningSchedule

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .trailing, spacing: 2) {
                Text(schedule.startTime)
                    .font(.system(size: 13, weight: .semibold))
                Text(schedule.endTime)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }
            .frame(width: 56)

            Rectangle()
                .fill(Color("StatusAmber"))
                .frame(width: 2, height: 36)
                .clipShape(Capsule())

            VStack(alignment: .leading, spacing: 2) {
                Text(street.name)
                    .font(.system(size: 15, weight: .semibold))
                Text("\(street.fromCross)–\(street.toCross) · \(street.neighborhood)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()

            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(Color("StatusAmber"))
                .font(.caption)
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    ScheduleView().environmentObject(ScheduleStore())
}
