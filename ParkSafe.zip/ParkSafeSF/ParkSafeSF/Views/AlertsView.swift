import SwiftUI

struct AlertsView: View {
    @EnvironmentObject var store: ScheduleStore

    var body: some View {
        NavigationStack {
            List {
                ForEach(store.alerts) { alert in
                    AlertRow(alert: alert)
                        .listRowInsets(EdgeInsets(top: 5, leading: 16, bottom: 5, trailing: 16))
                        .listRowBackground(Color.clear)
                        .listRowSeparator(.hidden)
                }
            }
            .listStyle(.plain)
            .navigationTitle("Alerts")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: {}) {
                        Image(systemName: "bell.slash")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .overlay {
                if store.alerts.isEmpty {
                    ContentUnavailableView(
                        "No Alerts",
                        systemImage: "bell.slash",
                        description: Text("Save streets on the map to start receiving parking alerts.")
                    )
                }
            }
        }
    }
}

struct AlertRow: View {
    let alert: AlertItem

    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Image(systemName: alert.icon)
                .font(.system(size: 18))
                .foregroundColor(alert.color)
                .frame(width: 40, height: 40)
                .background(alert.backgroundColor)
                .clipShape(Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(alert.title)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.primary)
                Text(alert.body)
                    .font(.system(size: 13))
                    .foregroundColor(.secondary)
                    .lineLimit(3)
                Text(alert.timeAgo)
                    .font(.caption)
                    .foregroundColor(.tertiary)
                    .padding(.top, 2)
            }
        }
        .padding(14)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    AlertsView().environmentObject(ScheduleStore())
}
