import SwiftUI
import MapKit

struct StreetFullDetailView: View {
    let street: StreetSegment
    @EnvironmentObject var store: ScheduleStore
    @EnvironmentObject var notificationManager: NotificationManager
    @Environment(\.dismiss) private var dismiss

    var isSaved: Bool { store.streets.first(where: { $0.id == street.id })?.isSaved ?? false }
    var status: ParkingStatus { street.parkingStatus }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {

                    // Status Banner
                    HStack(spacing: 14) {
                        Image(systemName: status.icon)
                            .font(.title2)
                            .foregroundColor(status.swiftUIColor)
                            .frame(width: 44, height: 44)
                            .background(status.backgroundSwiftUIColor)
                            .clipShape(Circle())

                        VStack(alignment: .leading, spacing: 3) {
                            Text(status.headline)
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(status.swiftUIColor)
                            Text(status.detail)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    .padding(16)
                    .background(status.backgroundSwiftUIColor)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    // Info card
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(street.name)
                                    .font(.title2.bold())
                                Text("\(street.fromCross) to \(street.toCross)")
                                    .font(.subheadline).foregroundColor(.secondary)
                                Text(street.neighborhood)
                                    .font(.caption).foregroundColor(Color("BrandGreen"))
                                    .fontWeight(.semibold)
                            }
                            Spacer()
                            Button(action: toggleSave) {
                                Image(systemName: isSaved ? "bookmark.fill" : "bookmark")
                                    .font(.system(size: 22))
                                    .foregroundColor(Color("BrandGreen"))
                            }
                        }
                    }
                    .padding(16)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    // Weekly schedule
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Weekly Schedule")
                            .font(.headline)
                        WeekStripView(street: street)

                        // List of cleaning days
                        ForEach(street.cleaningDays.sorted(by: { $0.weekday < $1.weekday }), id: \.weekday) { s in
                            HStack {
                                Text(s.weekdayName)
                                    .font(.system(size: 15, weight: .medium))
                                Spacer()
                                Text("\(s.startTime) – \(s.endTime)")
                                    .font(.system(size: 15))
                                    .foregroundColor(.secondary)
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundColor(Color("StatusAmber"))
                                    .font(.caption)
                            }
                            .padding(.vertical, 4)
                            Divider()
                        }
                    }
                    .padding(16)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    // Map thumbnail
                    Map(coordinateRegion: .constant(MKCoordinateRegion(
                        center: street.coordinate,
                        span: MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
                    )), annotationItems: [street]) { s in
                        MapMarker(coordinate: s.coordinate, tint: s.parkingStatus.swiftUIColor)
                    }
                    .frame(height: 160)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .disabled(true)

                    // Navigation buttons
                    VStack(spacing: 10) {
                        if let url = appleMapsURL {
                            Link(destination: url) {
                                HStack {
                                    Image(systemName: "map.fill")
                                    Text("Open in Apple Maps")
                                        .fontWeight(.semibold)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(Color("BrandGreen"))
                                .foregroundColor(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                        }
                        if let url = googleMapsURL {
                            Link(destination: url) {
                                HStack {
                                    Image(systemName: "location.fill")
                                    Text("Open in Google Maps")
                                        .fontWeight(.semibold)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(Color(.secondarySystemBackground))
                                .foregroundColor(.primary)
                                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color(.separator), lineWidth: 0.5))
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                        }
                    }
                }
                .padding(16)
            }
            .navigationTitle(street.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .foregroundColor(Color("BrandGreen"))
                }
            }
        }
    }

    private var appleMapsURL: URL? {
        let q = "\(street.name), San Francisco, CA".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return URL(string: "maps://?q=\(q)&ll=\(street.latitude),\(street.longitude)")
    }

    private var googleMapsURL: URL? {
        URL(string: "comgooglemaps://?q=\(street.latitude),\(street.longitude)")
            ?? URL(string: "https://maps.google.com/?q=\(street.latitude),\(street.longitude)")
    }

    private func toggleSave() {
        store.toggleSave(street)
    }
}
