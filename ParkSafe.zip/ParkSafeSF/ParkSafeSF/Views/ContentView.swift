import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: ScheduleStore
    @State private var selectedTab: Tab = .map

    enum Tab: Int { case map, alerts, schedule, settings }

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeMapView()
                .tabItem {
                    Label("Map", systemImage: selectedTab == .map ? "map.fill" : "map")
                }
                .tag(Tab.map)

            AlertsView()
                .tabItem {
                    Label("Alerts", systemImage: selectedTab == .alerts ? "bell.fill" : "bell")
                }
                .badge(2)
                .tag(Tab.alerts)

            ScheduleView()
                .tabItem {
                    Label("Schedule", systemImage: "calendar")
                }
                .tag(Tab.schedule)

            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: selectedTab == .settings ? "gearshape.fill" : "gearshape")
                }
                .tag(Tab.settings)
        }
        .tint(Color("BrandGreen"))
    }
}

#Preview {
    ContentView()
        .environmentObject(ScheduleStore())
        .environmentObject(LocationManager())
        .environmentObject(NotificationManager())
}
