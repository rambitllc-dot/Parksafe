import SwiftUI

struct SearchView: View {
    let onSelect: (StreetSegment) -> Void
    @EnvironmentObject var store: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @FocusState private var focused: Bool

    var results: [StreetSegment] {
        query.isEmpty ? store.streets :
        store.streets.filter {
            $0.name.localizedCaseInsensitiveContains(query) ||
            $0.neighborhood.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            List(results) { street in
                Button(action: { onSelect(street) }) {
                    HStack(spacing: 13) {
                        Image(systemName: "mappin.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.white, street.parkingStatus.swiftUIColor)
                            .frame(width: 40, height: 40)
                            .background(street.parkingStatus.backgroundSwiftUIColor)
                            .clipShape(Circle())

                        VStack(alignment: .leading, spacing: 2) {
                            Text(street.name).font(.system(size: 16, weight: .semibold))
                            Text("\(street.fromCross)–\(street.toCross) · \(street.neighborhood)")
                                .font(.caption).foregroundColor(.secondary)
                            Text(street.parkingStatus.headline)
                                .font(.caption.bold())
                                .foregroundColor(street.parkingStatus.swiftUIColor)
                        }

                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.tertiary)
                            .font(.caption)
                    }
                    .padding(.vertical, 2)
                }
                .buttonStyle(.plain)
            }
            .listStyle(.insetGrouped)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always),
                        prompt: "Street name or neighborhood…")
            .navigationTitle("Search Streets")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Cancel") { dismiss() }
                        .foregroundColor(Color("BrandGreen"))
                }
            }
        }
    }
}
