import SwiftUI
import MapKit

struct HomeMapView: View {
    @EnvironmentObject var store: ScheduleStore
    @EnvironmentObject var locationManager: LocationManager
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.769, longitude: -122.428),
        span: MKCoordinateSpan(latitudeDelta: 0.06, longitudeDelta: 0.06)
    )
    @State private var selectedStreet: StreetSegment?
    @State private var showSearch = false
    @State private var mapStyle: MapStyle = .standard
    @State private var showingDetail = false

    var body: some View {
        ZStack(alignment: .bottom) {
            // Map
            Map(coordinateRegion: $region,
                showsUserLocation: true,
                annotationItems: store.streets) { street in
                MapAnnotation(coordinate: street.coordinate) {
                    StreetPin(street: street, isSelected: selectedStreet?.id == street.id)
                        .onTapGesture { selectStreet(street) }
                }
            }
            .ignoresSafeArea()

            // Search bar (floating)
            VStack {
                Button(action: { showSearch = true }) {
                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.secondary)
                            .font(.system(size: 15))
                        Text("Search any street in SF…")
                            .foregroundColor(.secondary)
                            .font(.system(size: 15))
                        Spacer()
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 12)
                    .background(.regularMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .shadow(color: .black.opacity(0.1), radius: 8, y: 3)
                }
                .padding(.horizontal, 14)
                .padding(.top, 8)

                Spacer()
            }

            // Bottom sheet
            VStack(spacing: 0) {
                Capsule()
                    .fill(Color(.systemGray4))
                    .frame(width: 36, height: 4)
                    .padding(.top, 10)
                    .padding(.bottom, 4)

                if let street = selectedStreet {
                    StreetDetailCard(street: street, onShowFull: { showingDetail = true })
                        .padding(.horizontal, 14)
                        .padding(.bottom, 8)
                } else {
                    NearbyStrip(streets: store.streets.prefix(8).map { $0 }, onSelect: selectStreet)
                        .padding(.bottom, 8)
                }
            }
            .background(.regularMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .shadow(color: .black.opacity(0.12), radius: 20, y: -4)
        }
        .sheet(isPresented: $showSearch) {
            SearchView(onSelect: { street in
                showSearch = false
                selectStreet(street)
            })
        }
        .sheet(isPresented: $showingDetail) {
            if let street = selectedStreet {
                StreetFullDetailView(street: street)
            }
        }
        .onAppear { locationManager.requestPermission() }
    }

    private func selectStreet(_ street: StreetSegment) {
        withAnimation(.spring(response: 0.4)) {
            selectedStreet = street
            region.center = street.coordinate
        }
    }
}

// MARK: - Street Pin

struct StreetPin: View {
    let street: StreetSegment
    let isSelected: Bool

    var body: some View {
        ZStack {
            Circle()
                .fill(street.parkingStatus.swiftUIColor)
                .frame(width: isSelected ? 32 : 24, height: isSelected ? 32 : 24)
                .overlay(Circle().stroke(.white, lineWidth: 2.5))
                .shadow(color: street.parkingStatus.swiftUIColor.opacity(0.4),
                        radius: isSelected ? 8 : 4, y: 2)

            if isSelected {
                Circle()
                    .stroke(street.parkingStatus.swiftUIColor, lineWidth: 1.5)
                    .frame(width: 46, height: 46)
                    .opacity(0.35)
            }
        }
        .animation(.spring(response: 0.3), value: isSelected)
    }
}

// MARK: - Nearby Strip

struct NearbyStrip: View {
    let streets: [StreetSegment]
    let onSelect: (StreetSegment) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("NEARBY STREETS")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(.secondary)
                .padding(.horizontal, 16)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(streets) { street in
                        Button(action: { onSelect(street) }) {
                            VStack(alignment: .leading, spacing: 3) {
                                HStack(spacing: 5) {
                                    Circle()
                                        .fill(street.parkingStatus.swiftUIColor)
                                        .frame(width: 7, height: 7)
                                    Text(street.name)
                                        .font(.system(size: 13, weight: .semibold))
                                        .foregroundColor(.primary)
                                }
                                Text(street.nextCleaningDescription)
                                    .font(.system(size: 11))
                                    .foregroundColor(.secondary)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(.separator), lineWidth: 0.5)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14)
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Street Detail Card (bottom sheet)

struct StreetDetailCard: View {
    let street: StreetSegment
    let onShowFull: () -> Void
    @EnvironmentObject var store: ScheduleStore
    @EnvironmentObject var notificationManager: NotificationManager

    var isSaved: Bool { street.isSaved }
    var status: ParkingStatus { street.parkingStatus }

    var body: some View {
        VStack(spacing: 0) {
            // Status banner
            HStack(spacing: 12) {
                Image(systemName: status.icon)
                    .font(.title3)
                    .foregroundColor(status.swiftUIColor)
                    .frame(width: 38, height: 38)
                    .background(status.backgroundSwiftUIColor)
                    .clipShape(Circle())

                VStack(alignment: .leading, spacing: 2) {
                    Text(status.headline)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(status.swiftUIColor)
                    Text(status.detail)
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                }
                Spacer()
            }
            .padding(14)
            .background(status.backgroundSwiftUIColor)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

            // Street name row
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(street.name)
                        .font(.system(size: 20, weight: .bold))
                    Text("\(street.fromCross)–\(street.toCross) · \(street.neighborhood)")
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                }
                Spacer()
                Button(action: { toggleSave() }) {
                    Image(systemName: isSaved ? "bookmark.fill" : "bookmark")
                        .font(.system(size: 20))
                        .foregroundColor(Color("BrandGreen"))
                }
            }
            .padding(.top, 12)
            .padding(.horizontal, 2)

            // Week strip
            WeekStripView(street: street)
                .padding(.top, 10)

            // Action buttons
            HStack(spacing: 10) {
                if let url = appleMapsURL {
                    Link(destination: url) {
                        Label("Apple Maps", systemImage: "map.fill")
                            .font(.system(size: 13, weight: .medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 11))
                            .overlay(RoundedRectangle(cornerRadius: 11).stroke(Color(.separator), lineWidth: 0.5))
                    }
                }
                if let url = googleMapsURL {
                    Link(destination: url) {
                        Label("Google Maps", systemImage: "location.fill")
                            .font(.system(size: 13, weight: .medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 11))
                            .overlay(RoundedRectangle(cornerRadius: 11).stroke(Color(.separator), lineWidth: 0.5))
                    }
                }
            }
            .foregroundColor(.primary)
            .padding(.top, 10)
        }
    }

    private var appleMapsURL: URL? {
        let q = "\(street.name), San Francisco, CA".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return URL(string: "maps://?q=\(q)&ll=\(street.latitude),\(street.longitude)")
    }

    private var googleMapsURL: URL? {
        URL(string: "comgooglemaps://?q=\(street.latitude),\(street.longitude)")
            ?? URL(string: "https://maps.google.com/?q=\(street.latitude),\(street.longitude)")
    }

    private func toggleSave() {
        store.toggleSave(street)
        if !street.isSaved {
            notificationManager.scheduleWarning(for: street)
            notificationManager.scheduleNightBefore(for: street)
        } else {
            notificationManager.cancelNotifications(for: street)
        }
    }
}

// MARK: - Week Strip

struct WeekStripView: View {
    let street: StreetSegment
    private let symbols = Calendar.current.veryShortWeekdaySymbols

    var todayWeekday: Int { Calendar.current.component(.weekday, from: .now) }

    var body: some View {
        HStack(spacing: 5) {
            ForEach(1...7, id: \.self) { wd in
                let isToday = wd == todayWeekday
                let hasCleaning = street.cleaningDays.contains { $0.weekday == wd }
                let schedule = street.cleaningDays.first { $0.weekday == wd }

                VStack(spacing: 4) {
                    Text(symbols[wd - 1])
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(isToday ? .white : hasCleaning ? Color("StatusAmber") : .secondary)

                    Circle()
                        .fill(hasCleaning ? Color("StatusAmber") : .clear)
                        .frame(width: 4, height: 4)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 9)
                        .fill(isToday ? Color("BrandGreen") :
                              hasCleaning ? Color("StatusAmberBG") : Color(.secondarySystemBackground))
                )
            }
        }
    }
}

#Preview {
    HomeMapView()
        .environmentObject(ScheduleStore())
        .environmentObject(LocationManager())
        .environmentObject(NotificationManager())
}
