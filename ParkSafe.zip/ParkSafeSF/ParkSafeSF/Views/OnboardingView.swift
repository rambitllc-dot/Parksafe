import SwiftUI

struct OnboardingView: View {
    @Binding var hasCompletedOnboarding: Bool
    @EnvironmentObject var notificationManager: NotificationManager
    @State private var currentPage = 0

    private let pages: [OnboardingPage] = [
        OnboardingPage(
            icon: "mappin.circle.fill",
            iconColor: Color("BrandGreen"),
            title: "Never get a\nparking ticket again",
            subtitle: "ParkSafe shows you exactly which San Francisco streets have cleaning — and alerts you before it's too late.",
            artStyle: .map
        ),
        OnboardingPage(
            icon: "bell.badge.fill",
            iconColor: .orange,
            title: "Smart alerts,\nright on time",
            subtitle: "Get notified the night before, 30 minutes before, and the moment cleaning begins. No more last-minute sprints.",
            artStyle: .notification
        ),
        OnboardingPage(
            icon: "calendar.badge.clock",
            iconColor: .blue,
            title: "See the full\nweek at a glance",
            subtitle: "Your personalized weekly schedule shows every cleaning day for all your saved streets across SF.",
            artStyle: .schedule
        ),
    ]

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()

            VStack(spacing: 0) {
                TabView(selection: $currentPage) {
                    ForEach(pages.indices, id: \.self) { i in
                        OnboardingPageView(page: pages[i])
                            .tag(i)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .animation(.spring(response: 0.5), value: currentPage)

                // Page dots
                HStack(spacing: 8) {
                    ForEach(pages.indices, id: \.self) { i in
                        Capsule()
                            .fill(i == currentPage ? Color("BrandGreen") : Color(.systemGray4))
                            .frame(width: i == currentPage ? 22 : 7, height: 7)
                            .animation(.spring(response: 0.3), value: currentPage)
                    }
                }
                .padding(.top, 8)

                // Buttons
                VStack(spacing: 10) {
                    Button(action: advance) {
                        Text(currentPage < pages.count - 1 ? "Continue" : "Get Started")
                            .font(.system(size: 17, weight: .semibold))
                            .frame(maxWidth: .infinity)
                            .frame(height: 54)
                            .background(Color("BrandGreen"))
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    .padding(.horizontal, 24)

                    if currentPage < pages.count - 1 {
                        Button("Skip") {
                            finish()
                        }
                        .font(.system(size: 15))
                        .foregroundColor(.secondary)
                        .frame(height: 44)
                    } else {
                        Color.clear.frame(height: 44)
                    }
                }
                .padding(.top, 16)
                .padding(.bottom, 32)
            }
        }
    }

    private func advance() {
        if currentPage < pages.count - 1 {
            withAnimation { currentPage += 1 }
        } else {
            finish()
        }
    }

    private func finish() {
        notificationManager.requestPermission()
        withAnimation { hasCompletedOnboarding = true }
    }
}

// MARK: - Onboarding Page Model

struct OnboardingPage {
    let icon: String
    let iconColor: Color
    let title: String
    let subtitle: String
    let artStyle: ArtStyle
    enum ArtStyle { case map, notification, schedule }
}

// MARK: - Onboarding Page View

struct OnboardingPageView: View {
    let page: OnboardingPage

    var body: some View {
        VStack(spacing: 0) {
            // Art panel
            ZStack {
                RoundedRectangle(cornerRadius: 28)
                    .fill(page.iconColor.opacity(0.08))

                switch page.artStyle {
                case .map:         OnboardingMapArt()
                case .notification: OnboardingNotificationArt()
                case .schedule:    OnboardingScheduleArt()
                }
            }
            .frame(height: 300)
            .padding(.horizontal, 24)
            .padding(.top, 24)

            // Text
            VStack(alignment: .leading, spacing: 12) {
                Text(page.title)
                    .font(.system(size: 28, weight: .bold, design: .default))
                    .fixedSize(horizontal: false, vertical: true)
                    .foregroundColor(.primary)

                Text(page.subtitle)
                    .font(.system(size: 16))
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .lineSpacing(4)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 28)
            .padding(.top, 32)

            Spacer()
        }
    }
}

// MARK: - Art Views

struct OnboardingMapArt: View {
    var body: some View {
        ZStack {
            // Simulated map grid
            VStack(spacing: 0) {
                ForEach(0..<5) { row in
                    HStack(spacing: 0) {
                        ForEach(0..<4) { col in
                            Rectangle()
                                .fill(Color(.systemGray6))
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .overlay(
                                    Rectangle()
                                        .stroke(Color(.systemGray4), lineWidth: 0.5)
                                )
                        }
                    }
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 28))

            // Cleaning zone stripe
            Rectangle()
                .fill(Color.orange.opacity(0.25))
                .frame(height: 22)
                .offset(y: -40)

            // Pins
            HStack(spacing: 40) {
                StatusPin(color: Color("StatusGreen"))
                StatusPin(color: Color("StatusRed"))
                StatusPin(color: Color("StatusAmber"))
            }

            // Label
            Text("STREET CLEANING")
                .font(.system(size: 9, weight: .bold))
                .foregroundColor(.orange)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(Capsule().fill(Color.orange.opacity(0.15)))
                .offset(y: -40)
        }
    }
}

struct StatusPin: View {
    let color: Color
    var body: some View {
        Image(systemName: "mappin.circle.fill")
            .font(.system(size: 36))
            .foregroundStyle(.white, color)
            .shadow(color: color.opacity(0.4), radius: 8, y: 4)
    }
}

struct OnboardingNotificationArt: View {
    var body: some View {
        VStack(spacing: 12) {
            NotificationBubble(
                icon: "exclamationmark.triangle.fill",
                color: .orange,
                title: "Move in 30 minutes",
                subtitle: "Cleaning on Mission St starts at 8 AM"
            )
            NotificationBubble(
                icon: "xmark.circle.fill",
                color: Color("StatusRed"),
                title: "Cleaning started!",
                subtitle: "Move your car immediately"
            )
            .opacity(0.65)
            .scaleEffect(0.94)
        }
        .padding(.horizontal, 20)
    }
}

struct NotificationBubble: View {
    let icon: String; let color: Color; let title: String; let subtitle: String
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
                .frame(width: 40, height: 40)
                .background(color.opacity(0.12))
                .clipShape(Circle())

            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.bold()).foregroundColor(.primary)
                Text(subtitle).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding(14)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 3)
    }
}

struct OnboardingScheduleArt: View {
    private let days = ["S","M","T","W","T","F","S"]
    private let streets = ["Mission St", "Valencia St", "Castro St", "Haight St"]
    private let cleaning: [[Bool]] = [
        [false,false,true,false,false,true,false],
        [false,true,false,false,true,false,false],
        [false,true,false,false,true,false,false],
        [false,false,true,false,false,true,false],
    ]

    var body: some View {
        VStack(spacing: 6) {
            // Day header
            HStack(spacing: 0) {
                Text("Street").font(.system(size: 10, weight: .semibold)).foregroundColor(.secondary)
                    .frame(width: 80, alignment: .leading)
                ForEach(days, id: \.self) { d in
                    Text(d).font(.system(size: 10, weight: .bold)).foregroundColor(.secondary)
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 16)

            Divider().padding(.horizontal, 8)

            ForEach(streets.indices, id: \.self) { i in
                HStack(spacing: 0) {
                    Text(streets[i]).font(.system(size: 11, weight: .medium)).foregroundColor(.primary)
                        .frame(width: 80, alignment: .leading).lineLimit(1)
                    ForEach(cleaning[i].indices, id: \.self) { j in
                        if cleaning[i][j] {
                            RoundedRectangle(cornerRadius: 4)
                                .fill(Color.orange.opacity(0.25))
                                .overlay(
                                    Text("8").font(.system(size: 8, weight: .bold)).foregroundColor(.orange)
                                )
                                .frame(height: 22)
                                .padding(.horizontal, 2)
                                .frame(maxWidth: .infinity)
                        } else {
                            RoundedRectangle(cornerRadius: 4)
                                .fill(Color(.systemGray6))
                                .frame(height: 22)
                                .padding(.horizontal, 2)
                                .frame(maxWidth: .infinity)
                        }
                    }
                }
                .padding(.horizontal, 16)
            }
        }
        .padding(.vertical, 20)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .padding(.horizontal, 16)
    }
}

#Preview {
    OnboardingView(hasCompletedOnboarding: .constant(false))
        .environmentObject(NotificationManager())
}
