import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var notificationManager: NotificationManager
    @EnvironmentObject var store: ScheduleStore

    var body: some View {
        NavigationStack {
            List {
                // Maps
                Section("Maps Integration") {
                    MapsConnectRow(icon: "map.fill", iconBg: .blue,
                                   title: "Apple Maps", subtitle: "Open parked location & navigate",
                                   status: "Ready", statusColor: Color("StatusGreen"))
                    MapsConnectRow(icon: "location.fill", iconBg: .green,
                                   title: "Google Maps", subtitle: "Install Google Maps to enable",
                                   status: "Optional", statusColor: .secondary)
                    MapsConnectRow(icon: "car.fill", iconBg: .indigo,
                                   title: "Waze", subtitle: "Install Waze to enable",
                                   status: "Optional", statusColor: .secondary)
                }

                // Notifications
                Section("Notifications") {
                    if !notificationManager.isAuthorized {
                        Button(action: { notificationManager.requestPermission() }) {
                            Label("Enable Notifications", systemImage: "bell.badge.fill")
                                .foregroundColor(Color("BrandGreen"))
                        }
                    }

                    Toggle(isOn: $notificationManager.nightBeforeEnabled) {
                        Label {
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Night before reminder").font(.system(size: 15))
                                Text("Alert at 9 PM if you need to move").font(.caption).foregroundColor(.secondary)
                            }
                        } icon: {
                            Image(systemName: "moon.fill")
                                .foregroundColor(.purple)
                                .frame(width: 28, height: 28)
                                .background(Color.purple.opacity(0.12))
                                .clipShape(RoundedRectangle(cornerRadius: 7))
                        }
                    }
                    .tint(Color("BrandGreen"))

                    Toggle(isOn: $notificationManager.thirtyMinWarningEnabled) {
                        Label {
                            VStack(alignment: .leading, spacing: 1) {
                                Text("30-minute warning").font(.system(size: 15))
                                Text("Last chance before cleaning starts").font(.caption).foregroundColor(.secondary)
                            }
                        } icon: {
                            Image(systemName: "clock.fill")
                                .foregroundColor(.orange)
                                .frame(width: 28, height: 28)
                                .background(Color.orange.opacity(0.12))
                                .clipShape(RoundedRectangle(cornerRadius: 7))
                        }
                    }
                    .tint(Color("BrandGreen"))

                    Toggle(isOn: $notificationManager.cleaningStartedEnabled) {
                        Label {
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Cleaning started alert").font(.system(size: 15))
                                Text("Urgent if you're still parked").font(.caption).foregroundColor(.secondary)
                            }
                        } icon: {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundColor(Color("StatusRed"))
                                .frame(width: 28, height: 28)
                                .background(Color("StatusRed").opacity(0.12))
                                .clipShape(RoundedRectangle(cornerRadius: 7))
                        }
                    }
                    .tint(Color("BrandGreen"))

                    Toggle(isOn: $notificationManager.safeDayEnabled) {
                        Label {
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Safe day confirmation").font(.system(size: 15))
                                Text("Tell me when my street is clear").font(.caption).foregroundColor(.secondary)
                            }
                        } icon: {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(Color("StatusGreen"))
                                .frame(width: 28, height: 28)
                                .background(Color("StatusGreen").opacity(0.12))
                                .clipShape(RoundedRectangle(cornerRadius: 7))
                        }
                    }
                    .tint(Color("BrandGreen"))
                }

                // Saved streets
                Section("Saved Streets (\(store.savedStreets.count))") {
                    if store.savedStreets.isEmpty {
                        Text("No saved streets yet. Tap the bookmark icon on any street.")
                            .font(.subheadline).foregroundColor(.secondary)
                    } else {
                        ForEach(store.savedStreets) { street in
                            HStack {
                                Circle().fill(street.parkingStatus.swiftUIColor).frame(width: 9, height: 9)
                                Text(street.name).font(.system(size: 15))
                                Spacer()
                                Text(street.neighborhood).font(.caption).foregroundColor(.secondary)
                            }
                        }
                        .onDelete { offsets in
                            offsets.forEach { i in store.toggleSave(store.savedStreets[i]) }
                        }
                    }
                }

                // Data
                Section("Data") {
                    HStack {
                        Label("Data source", systemImage: "server.rack")
                        Spacer()
                        Text("SF Open Data").foregroundColor(.secondary).font(.subheadline)
                    }
                    HStack {
                        Label("Streets loaded", systemImage: "mappin.and.ellipse")
                        Spacer()
                        Text("25 streets").foregroundColor(.secondary).font(.subheadline)
                    }
                    Button(action: {}) {
                        Label("Refresh schedules", systemImage: "arrow.clockwise")
                            .foregroundColor(Color("BrandGreen"))
                    }
                }

                // About
                Section("About") {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0").foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Build")
                        Spacer()
                        Text("100").foregroundColor(.secondary)
                    }
                    Link(destination: URL(string: "https://data.sfgov.org")!) {
                        HStack {
                            Text("SF Open Data Portal")
                            Spacer()
                            Image(systemName: "arrow.up.right").font(.caption).foregroundColor(.secondary)
                        }
                    }
                    NavigationLink("Privacy Policy") { PrivacyPolicyView() }
                    NavigationLink("Terms of Service") { TermsView() }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.large)
            .onAppear { notificationManager.checkAuthorizationStatus() }
        }
    }
}

struct MapsConnectRow: View {
    let icon: String; let iconBg: Color; let title: String
    let subtitle: String; let status: String; let statusColor: Color

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .foregroundColor(.white)
                .frame(width: 32, height: 32)
                .background(iconBg)
                .clipShape(RoundedRectangle(cornerRadius: 8))

            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.system(size: 15))
                Text(subtitle).font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Text(status).font(.system(size: 12, weight: .semibold)).foregroundColor(statusColor)
        }
    }
}

struct PrivacyPolicyView: View {
    var body: some View {
        ScrollView {
            Text("""
ParkSafe SF Privacy Policy

Last updated: 2025

**Data We Collect**
- Location data (only when you grant permission) to show nearby street cleaning schedules
- Saved street preferences (stored locally on your device)
- No personal information is collected or transmitted to servers

**Location Data**
Location is used only to center the map and identify nearby streets. It is never shared with third parties.

**Notifications**
Notification preferences are stored locally on your device.

**Data Storage**
All data is stored locally using UserDefaults. We do not operate servers or collect analytics.

**Third-Party Data**
Street cleaning schedules are sourced from SF Open Data (data.sfgov.org), a public government dataset.

**Contact**
For privacy questions, contact: privacy@parksafesf.app
""")
            .padding()
        }
        .navigationTitle("Privacy Policy")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct TermsView: View {
    var body: some View {
        ScrollView {
            Text("""
ParkSafe SF Terms of Service

By using ParkSafe SF, you agree to these terms.

**Accuracy Disclaimer**
Street cleaning schedules are sourced from SF Open Data and may not reflect temporary schedule changes, holidays, or emergency modifications. Always verify with posted signs.

**No Liability**
ParkSafe SF is not responsible for parking tickets received while relying on this app. Users are responsible for checking posted signs.

**Acceptable Use**
This app is for personal, non-commercial use only.

**Changes**
We may update these terms at any time. Continued use constitutes acceptance.
""")
            .padding()
        }
        .navigationTitle("Terms of Service")
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    SettingsView()
        .environmentObject(NotificationManager())
        .environmentObject(ScheduleStore())
}
