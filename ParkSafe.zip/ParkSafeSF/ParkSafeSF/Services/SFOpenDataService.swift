import Foundation
import Combine

// MARK: - SF Open Data Service
// Fetches real street cleaning data from data.sfgov.org
// Falls back to bundled data if offline

class SFOpenDataService: ObservableObject {
    static let shared = SFOpenDataService()

    private let endpoint = "https://data.sfgov.org/resource/yhqp-riqs.json"
    private let cacheKey = "sfOpenDataCache"
    private let cacheAgeKey = "sfOpenDataCacheAge"
    private let cacheMaxAge: TimeInterval = 7 * 24 * 3600 // 1 week

    @Published var isLoading = false
    @Published var lastError: String?
    @Published var lastUpdated: Date?

    // Fetch streets from the API, returning parsed StreetSegments
    func fetchSchedules(limit: Int = 2000) async -> [StreetSegment]? {
        // Return cache if fresh
        if let cached = loadFromCache() {
            lastUpdated = UserDefaults.standard.object(forKey: cacheAgeKey) as? Date
            return cached
        }

        await MainActor.run { isLoading = true }

        var components = URLComponents(string: endpoint)!
        components.queryItems = [
            URLQueryItem(name: "$limit", value: "\(limit)"),
            URLQueryItem(name: "$where", value: "corridor_is_not_null"),
        ]

        guard let url = components.url else { return nil }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let raw = try JSONDecoder().decode([SFOpenDataRecord].self, from: data)
            let streets = parseRecords(raw)

            // Cache
            if let encoded = try? JSONEncoder().encode(streets) {
                UserDefaults.standard.set(encoded, forKey: cacheKey)
                UserDefaults.standard.set(Date(), forKey: cacheAgeKey)
            }

            await MainActor.run {
                isLoading = false
                lastUpdated = Date()
                lastError = nil
            }
            return streets
        } catch {
            await MainActor.run {
                isLoading = false
                lastError = error.localizedDescription
            }
            return nil
        }
    }

    private func loadFromCache() -> [StreetSegment]? {
        guard
            let age = UserDefaults.standard.object(forKey: cacheAgeKey) as? Date,
            Date().timeIntervalSince(age) < cacheMaxAge,
            let data = UserDefaults.standard.data(forKey: cacheKey),
            let streets = try? JSONDecoder().decode([StreetSegment].self, from: data)
        else { return nil }
        return streets
    }

    // MARK: - Parse API Records

    private func parseRecords(_ records: [SFOpenDataRecord]) -> [StreetSegment] {
        // Group by corridor name, aggregate schedules
        var grouped: [String: (SFOpenDataRecord, [CleaningSchedule])] = [:]

        for r in records {
            guard let name = r.streetname, !name.isEmpty else { continue }
            let sched = r.cleaningSchedule
            if var existing = grouped[name] {
                existing.1.append(contentsOf: sched)
                grouped[name] = existing
            } else {
                grouped[name] = (r, sched)
            }
        }

        return grouped.values.enumerated().compactMap { (i, pair) in
            let (record, schedules) = pair
            guard let name = record.streetname,
                  let lat = Double(record.latitude ?? ""),
                  let lng = Double(record.longitude ?? "")
            else { return nil }

            return StreetSegment(
                id: i + 1000,
                name: name,
                fromCross: record.fromcst ?? "",
                toCross: record.tocst ?? "",
                neighborhood: record.nhood ?? "San Francisco",
                latitude: lat,
                longitude: lng,
                cleaningDays: Array(Set(schedules).prefix(4))
            )
        }
        .sorted { $0.name < $1.name }
    }
}

// MARK: - SF Open Data Record (API response model)

struct SFOpenDataRecord: Codable {
    let streetname: String?
    let fromcst: String?
    let tocst: String?
    let nhood: String?
    let latitude: String?
    let longitude: String?
    let week1ofmonth: String?
    let week2ofmonth: String?
    let week3ofmonth: String?
    let week4ofmonth: String?
    let week5ofmonth: String?
    let weekday: String?
    let starthourofweekday: String?
    let endhourofweekday: String?

    var cleaningSchedule: [CleaningSchedule] {
        guard
            let wdStr = weekday,
            let startStr = starthourofweekday,
            let endStr = endhourofweekday,
            let start = Int(startStr),
            let end   = Int(endStr)
        else { return [] }

        // Map SF day names → Calendar.weekday (1=Sun)
        let dayMap: [String: Int] = [
            "Monday": 2, "Tuesday": 3, "Wednesday": 4,
            "Thursday": 5, "Friday": 6, "Saturday": 7, "Sunday": 1
        ]
        guard let wd = dayMap[wdStr] else { return [] }
        return [CleaningSchedule(weekday: wd, startHour: start, endHour: end)]
    }
}

// Make CleaningSchedule hashable for Set deduplication
extension CleaningSchedule: Hashable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(weekday)
        hasher.combine(startHour)
        hasher.combine(endHour)
    }
}
