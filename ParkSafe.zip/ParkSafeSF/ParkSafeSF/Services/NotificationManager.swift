import Foundation
import UserNotifications

class NotificationManager: ObservableObject {
    @Published var isAuthorized = false
    @Published var nightBeforeEnabled = true
    @Published var thirtyMinWarningEnabled = true
    @Published var cleaningStartedEnabled = true
    @Published var safeDayEnabled = false

    static let shared = NotificationManager()

    func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, _ in
            DispatchQueue.main.async { self.isAuthorized = granted }
        }
    }

    func checkAuthorizationStatus() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                self.isAuthorized = settings.authorizationStatus == .authorized
            }
        }
    }

    // Schedule a 30-min warning for a given street's next cleaning
    func scheduleWarning(for street: StreetSegment) {
        guard thirtyMinWarningEnabled else { return }

        let cal = Calendar.current
        guard let nextDate = nextCleaningDate(for: street) else { return }
        let fireDate = nextDate.addingTimeInterval(-1800)
        guard fireDate > Date() else { return }

        let content = UNMutableNotificationContent()
        content.title = "⏰ Move in 30 minutes"
        content.body = "Street cleaning on \(street.name) starts at \(street.parkingStatus.headline.components(separatedBy: " ").last ?? ""). Move your car now!"
        content.sound = .default
        content.badge = 1

        let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: fireDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
        let request = UNNotificationRequest(identifier: "warning-\(street.id)", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    // Schedule night-before reminder
    func scheduleNightBefore(for street: StreetSegment) {
        guard nightBeforeEnabled else { return }
        guard let nextDate = nextCleaningDate(for: street) else { return }

        var comps = Calendar.current.dateComponents([.year, .month, .day], from: nextDate.addingTimeInterval(-86400))
        comps.hour = 21; comps.minute = 0
        let fireDate = Calendar.current.date(from: comps) ?? Date()
        guard fireDate > Date() else { return }

        let content = UNMutableNotificationContent()
        content.title = "🌙 Parking reminder"
        content.body = "\(street.name) has street cleaning tomorrow. Remember to move your car before \(street.cleaningDays.first?.startTime ?? "the posted time")."
        content.sound = .default

        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
        let request = UNNotificationRequest(identifier: "night-\(street.id)", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    func cancelNotifications(for street: StreetSegment) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(
            withIdentifiers: ["warning-\(street.id)", "night-\(street.id)"]
        )
    }

    func cancelAll() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }

    private func nextCleaningDate(for street: StreetSegment) -> Date? {
        let cal = Calendar.current
        let today = cal.component(.weekday, from: .now)
        for offset in 0..<7 {
            let wd = (today - 1 + offset) % 7 + 1
            if let s = street.cleaningDays.first(where: { $0.weekday == wd }) {
                var comps = cal.dateComponents([.year, .month, .day], from: Date().addingTimeInterval(Double(offset) * 86400))
                comps.hour = s.startHour; comps.minute = 0
                return cal.date(from: comps)
            }
        }
        return nil
    }
}
