import Foundation
import CoreLocation
import UserNotifications

// MARK: - Parking Detection Engine
// Uses significant-change location updates to detect when the user
// has parked near a street-cleaning zone and auto-schedules notifications.

class ParkingDetectionEngine: NSObject, ObservableObject {
    static let shared = ParkingDetectionEngine()

    @Published var detectedStreet: StreetSegment?
    @Published var isMonitoring = false

    private let manager = CLLocationManager()
    private var knownStreets: [StreetSegment] = []
    private var lastKnownLocation: CLLocation?

    /// Radius (meters) to consider a street "nearby"
    private let detectionRadius: CLLocationDistance = 150

    override init() {
        super.init()
        manager.delegate = self
    }

    func startMonitoring(streets: [StreetSegment]) {
        knownStreets = streets
        guard CLLocationManager.significantLocationChangeMonitoringAvailable() else { return }
        manager.startMonitoringSignificantLocationChanges()
        isMonitoring = true
    }

    func stopMonitoring() {
        manager.stopMonitoringSignificantLocationChanges()
        isMonitoring = false
    }

    // MARK: - Detection Logic

    private func checkForNearbyCleaningStreets(near location: CLLocation) {
        let nearby = knownStreets.filter { street in
            let streetLocation = CLLocation(latitude: street.latitude, longitude: street.longitude)
            return location.distance(from: streetLocation) <= detectionRadius
        }

        guard let closest = nearby.min(by: {
            CLLocation(latitude: $0.latitude, longitude: $0.longitude).distance(from: location) <
            CLLocation(latitude: $1.latitude, longitude: $1.longitude).distance(from: location)
        }) else { return }

        let status = closest.parkingStatus

        // Only alert if cleaning is scheduled within 12 hours
        switch status {
        case .cleaningNow, .moveSoon, .cleaningToday, .cleaningTomorrow:
            DispatchQueue.main.async { self.detectedStreet = closest }
            scheduleAutoDetectNotification(for: closest, status: status)
        default:
            break
        }
    }

    private func scheduleAutoDetectNotification(for street: StreetSegment, status: ParkingStatus) {
        let content = UNMutableNotificationContent()
        content.sound = .default
        content.badge = 1

        switch status {
        case .cleaningNow:
            content.title = "🚨 Move your car NOW"
            content.body = "You're parked on \(street.name) during active street cleaning!"
        case .moveSoon(let mins, _):
            content.title = "⏰ \(mins) minutes to move"
            content.body = "Street cleaning on \(street.name) starts in \(mins) minutes."
        case .cleaningToday(let s):
            content.title = "🅿️ Parking alert"
            content.body = "You're parked on \(street.name). Cleaning at \(s.startTime) — move by then."
        case .cleaningTomorrow(let s):
            content.title = "🌙 Reminder for tomorrow"
            content.body = "\(street.name) has cleaning at \(s.startTime). Move before then."
        default:
            return
        }

        let request = UNNotificationRequest(
            identifier: "autodetect-\(street.id)",
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
        )
        UNUserNotificationCenter.current().add(request)
    }
}

// MARK: - CLLocationManagerDelegate

extension ParkingDetectionEngine: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        // Only re-check if moved more than 50m
        if let last = lastKnownLocation, location.distance(from: last) < 50 { return }
        lastKnownLocation = location
        checkForNearbyCleaningStreets(near: location)
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("ParkingDetectionEngine location error: \(error.localizedDescription)")
    }
}
