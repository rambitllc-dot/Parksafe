import Foundation
import CoreLocation
import SwiftUI

// MARK: - City
// One entry per supported city. Adding a new city = one struct here
// + a JSON file in Resources/CityData/{city_id}.json

struct City: Identifiable, Codable, Equatable, Hashable {
    let id: String                  // "san_francisco", "new_york", "tokyo"
    let nameKey: String             // Localizable.strings key
    let country: String             // ISO 3166-1 alpha-2
    let timeZoneIdentifier: String
    let center: CityCoordinate
    let defaultZoom: Double
    let dataSourceURL: String?
    let dataSourceType: DataSourceType
    let isAvailable: Bool
    let streetNameLanguage: String  // BCP 47

    var timeZone: TimeZone { TimeZone(identifier: timeZoneIdentifier) ?? .current }
    var localizedName: String { NSLocalizedString(nameKey, comment: "") }
    var flagEmoji: String {
        country.unicodeScalars.reduce("") { r, s in
            guard let b = Unicode.Scalar(127397 + s.value) else { return r }
            return r + String(b)
        }
    }

    enum DataSourceType: String, Codable {
        case bundledJSON, openData, hybrid
    }
}

struct CityCoordinate: Codable, Equatable {
    let latitude: Double
    let longitude: Double
    var clCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

// MARK: - City Registry

struct CityRegistry {
    static let all: [City] = [
        City(id: "san_francisco",
             nameKey: "city.san_francisco",
             country: "US",
             timeZoneIdentifier: "America/Los_Angeles",
             center: CityCoordinate(latitude: 37.7749, longitude: -122.4194),
             defaultZoom: 0.06,
             dataSourceURL: "https://data.sfgov.org/resource/yhqp-riqs.json",
             dataSourceType: .hybrid,
             isAvailable: true,
             streetNameLanguage: "en"),

        City(id: "new_york",
             nameKey: "city.new_york",
             country: "US",
             timeZoneIdentifier: "America/New_York",
             center: CityCoordinate(latitude: 40.7128, longitude: -74.0060),
             defaultZoom: 0.05,
             dataSourceURL: "https://data.cityofnewyork.us/resource/svnu-bbfn.json",
             dataSourceType: .openData,
             isAvailable: false,
             streetNameLanguage: "en"),

        City(id: "sao_paulo",
             nameKey: "city.sao_paulo",
             country: "BR",
             timeZoneIdentifier: "America/Sao_Paulo",
             center: CityCoordinate(latitude: -23.5505, longitude: -46.6333),
             defaultZoom: 0.06,
             dataSourceURL: nil,
             dataSourceType: .bundledJSON,
             isAvailable: false,
             streetNameLanguage: "pt"),

        City(id: "buenos_aires",
             nameKey: "city.buenos_aires",
             country: "AR",
             timeZoneIdentifier: "America/Argentina/Buenos_Aires",
             center: CityCoordinate(latitude: -34.6037, longitude: -58.3816),
             defaultZoom: 0.06,
             dataSourceURL: nil,
             dataSourceType: .bundledJSON,
             isAvailable: false,
             streetNameLanguage: "es"),

        City(id: "mexico_city",
             nameKey: "city.mexico_city",
             country: "MX",
             timeZoneIdentifier: "America/Mexico_City",
             center: CityCoordinate(latitude: 19.4326, longitude: -99.1332),
             defaultZoom: 0.06,
             dataSourceURL: nil,
             dataSourceType: .bundledJSON,
             isAvailable: false,
             streetNameLanguage: "es"),

        City(id: "tokyo",
             nameKey: "city.tokyo",
             country: "JP",
             timeZoneIdentifier: "Asia/Tokyo",
             center: CityCoordinate(latitude: 35.6762, longitude: 139.6503),
             defaultZoom: 0.04,
             dataSourceURL: nil,
             dataSourceType: .bundledJSON,
             isAvailable: false,
             streetNameLanguage: "ja"),

        City(id: "berlin",
             nameKey: "city.berlin",
             country: "DE",
             timeZoneIdentifier: "Europe/Berlin",
             center: CityCoordinate(latitude: 52.5200, longitude: 13.4050),
             defaultZoom: 0.06,
             dataSourceURL: nil,
             dataSourceType: .bundledJSON,
             isAvailable: false,
             streetNameLanguage: "de"),

        City(id: "rome",
             nameKey: "city.rome",
             country: "IT",
             timeZoneIdentifier: "Europe/Rome",
             center: CityCoordinate(latitude: 41.9028, longitude: 12.4964),
             defaultZoom: 0.05,
             dataSourceURL: nil,
             dataSourceType: .bundledJSON,
             isAvailable: false,
             streetNameLanguage: "it"),

        City(id: "shanghai",
             nameKey: "city.shanghai",
             country: "CN",
             timeZoneIdentifier: "Asia/Shanghai",
             center: CityCoordinate(latitude: 31.2304, longitude: 121.4737),
             defaultZoom: 0.05,
             dataSourceURL: nil,
             dataSourceType: .bundledJSON,
             isAvailable: false,
             streetNameLanguage: "zh-Hans"),
    ]

    static var available: [City]  { all.filter  { $0.isAvailable  } }
    static var comingSoon: [City] { all.filter  { !$0.isAvailable } }
    static func city(id: String) -> City? { all.first { $0.id == id } }

    static func nearest(to location: CLLocation) -> City? {
        available.min {
            CLLocation(latitude: $0.center.latitude, longitude: $0.center.longitude)
                .distance(from: location) <
            CLLocation(latitude: $1.center.latitude, longitude: $1.center.longitude)
                .distance(from: location)
        }
    }
}

// MARK: - Street Segment (city-aware)

struct StreetSegment: Identifiable, Codable, Equatable {
    let id: Int
    let cityId: String
    let name: String
    let fromCross: String
    let toCross: String
    let neighborhood: String
    let latitude: Double
    let longitude: Double
    let cleaningDays: [CleaningSchedule]
    var isSaved: Bool = false

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
    var parkingStatus: ParkingStatus { ParkingStatus.compute(for: self) }
    var nextCleaningDescription: String { ParkingStatus.nextCleaningDescription(for: self) }

    enum CodingKeys: String, CodingKey {
        case id, cityId, name, fromCross, toCross, neighborhood,
             latitude, longitude, cleaningDays, isSaved
    }
}

// MARK: - Cleaning Schedule

struct CleaningSchedule: Codable, Equatable, Hashable {
    let weekday: Int   // 1=Sun … 7=Sat (Calendar.weekday)
    let startHour: Int
    let endHour: Int

    var startTime: String  { formatHour(startHour) }
    var endTime: String    { formatHour(endHour)   }
    var weekdayName: String { Calendar.current.weekdaySymbols[weekday - 1] }
    var weekdayShort: String { Calendar.current.shortWeekdaySymbols[weekday - 1] }

    private func formatHour(_ h: Int) -> String {
        let date = Calendar.current.date(bySettingHour: h, minute: 0, second: 0, of: Date())!
        let f = DateFormatter()
        f.dateFormat = "h a"
        return f.string(from: date)
    }
}

// MARK: - Parking Status

enum ParkingStatus: Equatable {
    case safe
    case cleaningTomorrow(schedule: CleaningSchedule)
    case cleaningToday(schedule: CleaningSchedule)
    case moveSoon(minutesLeft: Int, schedule: CleaningSchedule)
    case cleaningNow(schedule: CleaningSchedule)

    var swiftUIColor: Color {
        switch self {
        case .safe:                              return Color("StatusGreen")
        case .cleaningTomorrow, .cleaningToday:  return Color("StatusAmber")
        case .moveSoon, .cleaningNow:            return Color("StatusRed")
        }
    }
    var backgroundSwiftUIColor: Color {
        switch self {
        case .safe:                              return Color("StatusGreenBG")
        case .cleaningTomorrow, .cleaningToday:  return Color("StatusAmberBG")
        case .moveSoon, .cleaningNow:            return Color("StatusRedBG")
        }
    }
    var icon: String {
        switch self {
        case .safe:             return "checkmark.circle.fill"
        case .cleaningTomorrow: return "clock.fill"
        case .cleaningToday:    return "exclamationmark.triangle.fill"
        case .moveSoon:         return "exclamationmark.triangle.fill"
        case .cleaningNow:      return "xmark.circle.fill"
        }
    }

    var headline: String {
        switch self {
        case .safe:
            return String(localized: "status.safe")
        case .cleaningTomorrow(let s):
            return String(format: String(localized: "status.tomorrow"), s.startTime)
        case .cleaningToday(let s):
            return String(format: String(localized: "status.today"), s.startTime)
        case .moveSoon(let mins, _):
            return String(format: String(localized: "status.soon"), mins)
        case .cleaningNow(let s):
            return String(format: String(localized: "status.now"), s.endTime)
        }
    }
    var detail: String {
        switch self {
        case .safe:
            return String(localized: "status.safe.detail")
        case .cleaningTomorrow(let s):
            return String(format: String(localized: "status.tomorrow.detail"), s.startTime, s.endTime)
        case .cleaningToday(let s), .moveSoon(_, let s):
            return String(format: String(localized: "status.today.detail"), s.startTime, s.endTime)
        case .cleaningNow:
            return String(localized: "status.now.detail")
        }
    }

    static func compute(for street: StreetSegment, date: Date = .now) -> ParkingStatus {
        let cal     = Calendar.current
        let weekday = cal.component(.weekday, from: date)
        let cur     = cal.component(.hour, from: date) * 60 + cal.component(.minute, from: date)

        for s in street.cleaningDays where s.weekday == weekday {
            let sm = s.startHour * 60, em = s.endHour * 60
            if cur >= sm && cur < em { return .cleaningNow(schedule: s) }
            if cur < sm {
                let diff = sm - cur
                return diff <= 30 ? .moveSoon(minutesLeft: diff, schedule: s) : .cleaningToday(schedule: s)
            }
        }
        let tom = weekday % 7 + 1
        if let s = street.cleaningDays.first(where: { $0.weekday == tom }) {
            return .cleaningTomorrow(schedule: s)
        }
        return .safe
    }

    static func nextCleaningDescription(for street: StreetSegment, date: Date = .now) -> String {
        let today = Calendar.current.component(.weekday, from: date)
        for offset in 0..<7 {
            let wd = (today - 1 + offset) % 7 + 1
            if let s = street.cleaningDays.first(where: { $0.weekday == wd }) {
                if offset == 0 { return String(format: String(localized: "schedule.today_time"), s.startTime, s.endTime) }
                if offset == 1 { return String(format: String(localized: "schedule.tomorrow_time"), s.startTime, s.endTime) }
                return String(format: String(localized: "schedule.weekday_time"), s.weekdayName, s.startTime, s.endTime)
            }
        }
        return String(localized: "schedule.no_upcoming")
    }
}

// MARK: - Alert Item

struct AlertItem: Identifiable {
    let id        = UUID()
    let type:       AlertType
    let title:      String
    let body:       String
    let timestamp:  Date
    enum AlertType { case danger, warning, safe, info }

    var color: Color {
        switch type {
        case .danger:  return Color("StatusRed")
        case .warning: return Color("StatusAmber")
        case .safe:    return Color("StatusGreen")
        case .info:    return .blue
        }
    }
    var backgroundColor: Color {
        switch type {
        case .danger:  return Color("StatusRedBG")
        case .warning: return Color("StatusAmberBG")
        case .safe:    return Color("StatusGreenBG")
        case .info:    return Color(.systemBlue).opacity(0.12)
        }
    }
    var icon: String {
        switch type {
        case .danger:  return "exclamationmark.triangle.fill"
        case .warning: return "clock.fill"
        case .safe:    return "checkmark.circle.fill"
        case .info:    return "info.circle.fill"
        }
    }
    var timeAgo: String {
        let i = Date().timeIntervalSince(timestamp)
        if i < 3600  { return String(format: String(localized: "time.minutes_ago"), Int(i/60)) }
        if i < 86400 { return String(format: String(localized: "time.hours_ago"),   Int(i/3600)) }
        let d = Int(i/86400)
        return d == 1 ? String(localized: "time.yesterday") : String(format: String(localized: "time.days_ago"), d)
    }
}
